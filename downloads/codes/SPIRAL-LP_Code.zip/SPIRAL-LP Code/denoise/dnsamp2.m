function y = dnsamp2(x)

y = x(1:2:end,1:2:end);
