%% Zero finding Algorithm using Fixed point iteration method
% by Lasith Adhikari and Roummel Marcia

% Based on the paper
% W.Zuo et al., "A Generalized Iterated Shrinkage Algorithm for Non-convex Sparse Coding"

function [funcMin] = GST(sVect,p,lambda,gamma)

%------Input------
% sVect = s-value vector
% p     = p-value
% lambda= lambda value
% gamma = threshold for s


% initialize output x vectors
size    = length(sVect);
fvect   = zeros(size,1);


J       = 1000;     % #max iterations for fixed point method
epsilon = 1.e-12;   % Tolerance


for j = 1:size
    s = sVect(j);   % pick j-th s-value to find the zero
    
    %% Fixed point iteration method
    %k = 0;
    
    if s <= gamma
        Tp = 0;
    else
        f = s; % Initial guess (always greater than positve gamma)
        
        for i = 0:J
            
            f1 = s - lambda*p*(f)^(p-1);
            %k  = k+1;
            
            if abs(f - f1) < epsilon
                Tp = f1;
                break;
            end
                      
            f  = f1;
            
            
        end
        

    end
    
    fvect(j)   = Tp;
    
end

%-----output----
funcMin = fvect; 
